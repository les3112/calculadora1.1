import "./App.css";
import WeatherApp from "./components/weather/weatherApp";

function App() {
  return <WeatherApp />;
}

export default App;
