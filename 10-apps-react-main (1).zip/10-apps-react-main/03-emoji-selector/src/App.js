import "./App.css";

import EmojiPickerInput from "./components/emojiPicker/emojiPickerInput";

function App() {
  return (
    <div className="App">
      <EmojiPickerInput />
    </div>
  );
}

export default App;
