import Modal from "./modal";

export default function SettingsModal({ title, root }) {
  return (
    <Modal title={title} root={root}>
      Modal de settings
    </Modal>
  );
}
