import logo from "./logo.svg";
import "./App.css";
import Tiktok from "./components/tiktok";

function App() {
  return (
    <div className="App">
      <Tiktok />
    </div>
  );
}

export default App;
