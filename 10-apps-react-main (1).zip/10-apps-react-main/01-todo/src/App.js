import "./App.css";
import TodoApp from "./components/todoApp";

function App() {
  return <TodoApp />;
}
export default App;
