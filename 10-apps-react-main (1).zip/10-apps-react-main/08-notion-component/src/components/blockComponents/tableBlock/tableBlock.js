import { forwardRef } from "react";

function TableBlock() {
  return <div>Table</div>;
}

export default forwardRef(TableBlock);
