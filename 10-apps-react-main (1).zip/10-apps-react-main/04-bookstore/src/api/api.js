export default data = [
  {
    id: "2ad6b5e2-9c2b-4959-b740-9335c85eed74",
    title: "Harry Potter y el caliz de fuego",
    author: "J.K. Rowling",
    cover: "",
    intro: "",
    completed: false,
    review: "",
  },
  {
    id: "9942219d-eecc-42b5-a421-2d9b12736b76",
    title: "Los ojos de la ciudad",
    author: "Marcos Rivas",
    cover: "",
    intro: "",
    completed: false,
    review: "",
  },
];
